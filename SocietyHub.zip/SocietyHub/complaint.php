<?php
require 'db.php'; session_start();
if (isset($_POST['submit']) && !empty($_SESSION['loggedin'])) {
  $st = mysqli_prepare($conn, "INSERT INTO combox (Title,complaint) VALUES (?,?)");
  mysqli_stmt_bind_param($st, "ss", $_POST['title'], $_POST['complaint']);
  if (mysqli_stmt_execute($st)) alert_go('Complaint registered successfully...!', 'welcome.php');
  alert_go('Failed to register complaint.', 'complaint.php');
}
$title = "Complaint";
require 'header_user.php';
?>
<h2 class="ptitle">Register Your Anonymous complaints</h2>
<form method="POST" class="cform">
  <input type="text" name="title" class="field" placeholder="Title" required>
  <textarea name="complaint" class="field" placeholder="Enter Your Complaint" required></textarea>
  <div><button type="submit" name="submit" class="btn">Lodge complaint</button> <button type="reset" class="btn">Cancel</button></div>
</form>
<?php require 'footer.php'; ?>
