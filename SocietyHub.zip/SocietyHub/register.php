<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $st = mysqli_prepare($conn, "INSERT INTO registration (Username,Email,Flatno,MobileNo,`nno of family members`,Password) VALUES (?,?,?,?,?,?)");
  mysqli_stmt_bind_param($st, "ssiiis", $_POST['username'], $_POST['email'], $_POST['flatno'], $_POST['mobno'], $_POST['fammem'], $_POST['password']);
  if (mysqli_stmt_execute($st)) alert_go('Registration successfull...you may now login.', 'login.html');
}
alert_go('Registration Failed...Please try again.!!', 'login.html');
