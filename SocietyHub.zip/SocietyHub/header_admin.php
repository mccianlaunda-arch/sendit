<?php need_admin(); $active = basename($_SERVER['PHP_SELF']); ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?></title>
<link rel="stylesheet" href="dashstyle.css">
</head><body>
<div class="topbar"><div class="brand">SOCIETYHUB</div><span class="menu">☰</span><a href="logout.php" class="logout">Logout</a></div>
<div class="layout">
  <aside class="sidebar">
    <img src="img/adminlogin.jpg" class="avatar">
    <h4>Admin</h4>
    <a href="managemem.php" class="<?= $active=='managemem.php'?'on':'' ?>">▭ Manage Members</a>
    <a href="addnotice.php" class="<?= $active=='addnotice.php'?'on':'' ?>">📢 Add Notice</a>
    <a href="viewcomplaints.php" class="<?= $active=='viewcomplaints.php'?'on':'' ?>">👤 View Complaints</a>
    <a href="photo.php" class="<?= $active=='photo.php'?'on':'' ?>">🖼 Photo Gallery</a>
  </aside>
  <main class="content">
