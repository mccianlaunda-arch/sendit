<?php
// Shared by picadd.php (user) and insertfile.php (admin)
function handle_upload($conn, $back){
  if (isset($_POST['submit']) && isset($_FILES['my_image'])) {
    $f = $_FILES['my_image'];
    if ($f['error'] !== 0) { header("Location: $back?error=" . urlencode("Unknown error occurred!")); exit; }
    if ($f['size'] > 5000000) { header("Location: $back?error=" . urlencode("Sorry, your file is too large.")); exit; }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','gif','webp'])) { header("Location: $back?error=" . urlencode("You can't upload files of this type")); exit; }
    $new = uniqid("IMG-", true) . '.' . $ext;
    move_uploaded_file($f['tmp_name'], __DIR__ . '/uploads/' . $new);
    $st = mysqli_prepare($conn, "INSERT INTO images (image_url) VALUES (?)");
    mysqli_stmt_bind_param($st, "s", $new);
    mysqli_stmt_execute($st);
  }
  header("Location: $back"); exit;
}
