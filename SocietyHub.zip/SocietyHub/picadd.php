<?php require 'db.php'; require 'upload_handler.php'; need_user(); handle_upload($conn, 'userphoto.php');
