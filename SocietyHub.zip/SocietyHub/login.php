<?php
require 'db.php';
session_start();
$st = mysqli_prepare($conn, "SELECT Username FROM registration WHERE Username=? AND Email=? AND Flatno=? AND Password=?");
mysqli_stmt_bind_param($st, "ssis", $_POST['username'], $_POST['email'], $_POST['flatno'], $_POST['password']);
mysqli_stmt_execute($st);
$r = mysqli_stmt_get_result($st);
if (mysqli_num_rows($r) == 1) {
  $_SESSION['loggedin'] = true;
  $_SESSION['username'] = $_POST['username'];
  alert_go('Welcome,You are logged in...!', 'welcome.php');
}
alert_go('Sorry,Invalid credentials...!', 'login.html');
