<?php
session_start();
if (isset($_POST['logina'])) {
  if ($_POST['username'] == "Admin" && $_POST['admincode'] == "100") {
    $_SESSION['admin'] = true;
    echo "<script>alert('Welcome,You are logged in...!'); window.location.href='managemem.php';</script>"; exit;
  } else {
    echo "<script>alert('Sorry,Please enter valid details.!!');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adminlogin</title>
<link rel="stylesheet" href="style1.css">
</head><body>
<div class="page">
  <div class="navbar">
    <img src="img/shlogo.jpg" class="logo">
    <h1>Society<span class="hub">HUB</span></h1>
    <nav><ul><li><a href="login.html" class="active">Home</a></li><li><a href="login.html#rules">Rules &amp; Regulations</a></li></ul></nav>
    <a href="login.html" class="btn">User Login</a>
  </div>
  <div class="row">
    <div class="col-1"><img src="img/building1.jpg"></div>
    <div class="col-2">
      <div class="form-container1">
        <div class="adminfbtn"><h1>Admin Login</h1></div>
        <img src="img/adminlogin.jpg" class="admimg">
        <form action="adminlogin.php" method="POST">
          <input type="text" placeholder="Username" name="username" required>
          <input type="text" placeholder="Admin Code" name="admincode" required>
          <button type="submit" class="btn-losi" name="logina">Login</button>
        </form>
      </div>
    </div>
  </div>
</div>
</body></html>
