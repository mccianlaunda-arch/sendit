CREATE DATABASE IF NOT EXISTS usersregister;
USE usersregister;
CREATE TABLE IF NOT EXISTS registration (
  Id INT AUTO_INCREMENT PRIMARY KEY,
  Username VARCHAR(50) NOT NULL,
  Email VARCHAR(50) NOT NULL,
  Flatno INT NOT NULL,
  MobileNo BIGINT NOT NULL,
  `nno of family members` INT NOT NULL,
  Password VARCHAR(20) NOT NULL
);
CREATE TABLE IF NOT EXISTS notices (
  Id INT AUTO_INCREMENT PRIMARY KEY,
  Name VARCHAR(100) NOT NULL,
  Type VARCHAR(20) NOT NULL,
  Noticedate DATE NOT NULL,
  Message VARCHAR(500) NOT NULL
);
CREATE TABLE IF NOT EXISTS combox (
  Id INT AUTO_INCREMENT PRIMARY KEY,
  Title VARCHAR(100) NOT NULL,
  complaint VARCHAR(500) NOT NULL
);
CREATE TABLE IF NOT EXISTS images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  image_url TEXT NOT NULL
);
INSERT INTO registration (Username,Email,Flatno,MobileNo,`nno of family members`,Password) VALUES
('Sonali','sonali@gmail.com',112,9876543210,4,'sonali123'),
('Sonali2','sonali2@gmail.com',112,9876543211,3,'sonali123'),
('Rahul','rahul@gmail.com',203,9123456780,4,'rahul123');
INSERT INTO notices (Name,Type,Noticedate,Message) VALUES
('Lack of water supply','Announcement','2021-04-10','There is a water shortage on Sunday due to tank cleaning. Please store water in advance.'),
('General Meeting','Meeting','2021-04-15','Monthly society meeting will be held in the community hall at 6 PM. All members must attend.'),
('Holi Celebration','Event','2021-03-27','Holi celebration will be held in the society compound. Everyone is welcome.');
INSERT INTO combox (Title,complaint) VALUES
('Leakage problem','There is water leakage in the corridor of the 2nd floor. Kindly fix it soon.'),
('Garbage complaint','Garbage is not collected on time from the lobby.');
INSERT INTO images (image_url) VALUES ('sample1.jpg'),('sample2.jpg'),('sample3.jpg');
