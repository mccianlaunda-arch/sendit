<?php
// Database connection (your XAMPP MySQL runs on port 3307; change to 3306 if default)
$conn = mysqli_connect("localhost", "root", "", "usersregister", 3307);
if (!$conn) { die("Sorry we failed to connect: " . mysqli_connect_error()); }
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function need_user(){ session_start(); if(empty($_SESSION['loggedin'])){ header("location: login.html"); exit; } }
function need_admin(){ session_start(); if(empty($_SESSION['admin'])){ header("location: adminlogin.php"); exit; } }
function alert_go($msg,$url){ echo "<script>alert(".json_encode($msg)."); window.location.href=".json_encode($url).";</script>"; exit; }
