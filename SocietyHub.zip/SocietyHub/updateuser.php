<?php
require 'db.php'; need_admin();
if (isset($_POST['update'])) {
  $st = mysqli_prepare($conn, "UPDATE registration SET Username=?, Email=?, Flatno=?, MobileNo=?, `nno of family members`=? WHERE Id=?");
  mysqli_stmt_bind_param($st, "ssiiii", $_POST['username'], $_POST['email'], $_POST['flatno'], $_POST['mobno'], $_POST['fammem'], $_POST['id']);
  mysqli_stmt_execute($st);
  alert_go('Member updated successfully...!', 'managemem.php');
}
$st = mysqli_prepare($conn, "SELECT * FROM registration WHERE Id=?");
mysqli_stmt_bind_param($st, "i", $_GET['id']);
mysqli_stmt_execute($st);
$r = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
if (!$r) { header("Location: managemem.php"); exit; }
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Update Member</title><link rel="stylesheet" href="dashstyle.css"></head>
<body class="mint">
<form method="POST" class="mbox">
  <h2>Update Member</h2>
  <input type="hidden" name="id" value="<?= e($r['Id']) ?>">
  <input name="username" value="<?= e($r['Username']) ?>" required>
  <input type="email" name="email" value="<?= e($r['Email']) ?>" required>
  <input name="flatno" value="<?= e($r['Flatno']) ?>" required>
  <input name="mobno" value="<?= e($r['MobileNo']) ?>" required>
  <input name="fammem" value="<?= e($r['nno of family members']) ?>" required>
  <button name="update" class="btn small">Update Data</button>
</form></body></html>
