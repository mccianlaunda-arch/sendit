<?php
require 'db.php'; session_start();
$title = "Manage Members";
require 'header_admin.php';
$res = mysqli_query($conn, "SELECT * FROM registration");
?>
<a href="insertuser.php" class="btn small">Add Member</a>
<table class="tbl">
  <tr><th>Id</th><th>Username</th><th>Email</th><th>Flat No.</th><th>Mobile No.</th><th>No. of Family Members</th><th>Update</th><th>Delete</th></tr>
  <?php while($r = mysqli_fetch_assoc($res)): ?>
  <tr>
    <td><?= e($r['Id']) ?></td><td><?= e($r['Username']) ?></td><td><?= e($r['Email']) ?></td>
    <td><?= e($r['Flatno']) ?></td><td><?= e($r['MobileNo']) ?></td><td><?= e($r['nno of family members']) ?></td>
    <td><a class="btn small" href="updateuser.php?id=<?= e($r['Id']) ?>">Update</a></td>
    <td><a class="btn small" href="deleteuser.php?id=<?= e($r['Id']) ?>" onclick="return confirm('Delete this member?')">Delete</a></td>
  </tr>
  <?php endwhile; ?>
</table>
<?php require 'footer.php'; ?>
