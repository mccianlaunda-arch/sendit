<?php need_user(); $active = basename($_SERVER['PHP_SELF']); ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?></title>
<link rel="stylesheet" href="dashstyle.css">
</head><body>
<div class="topbar"><div class="brand">SOCIETYHUB</div><span class="menu">☰</span><a href="logout.php" class="logout">Logout</a></div>
<div class="layout">
  <aside class="sidebar">
    <img src="img/user.png" class="avatar">
    <h4><?= e($_SESSION['username']) ?></h4>
    <a href="welcome.php" class="<?= $active=='welcome.php'?'on':'' ?>">▭ Dashboard</a>
    <a href="noticebrd.php" class="<?= $active=='noticebrd.php'?'on':'' ?>">📢 Notice Board</a>
    <a href="complaint.php" class="<?= $active=='complaint.php'?'on':'' ?>">👤 Register Complaint</a>
    <a href="userphoto.php" class="<?= $active=='userphoto.php'?'on':'' ?>">🖼 Photo Gallery</a>
  </aside>
  <main class="content">
