SOCIETYHUB - Society Management System (PHP + MySQL)

RUN (3 steps)
1. Install XAMPP, start Apache and MySQL.
2. Copy this folder "SocietyHub" into C:\xampp\htdocs\
   Open http://localhost:81/phpmyadmin -> Import -> choose database.sql -> Go
   (creates database "usersregister" with sample data)
3. Open http://localhost:81/SocietyHub/login.html

LOGINS
Member : Username Sonali | Email sonali@gmail.com | Flat 112 | Password sonali123
Admin  : click "Admin Login" -> Username: Admin | Admin Code: 100

MySQL port is set to 3307 in db.php (change to 3306 if yours is default).
