<?php
require 'db.php'; session_start();
$title = "View Complaints";
require 'header_admin.php';
$res = mysqli_query($conn, "SELECT * FROM combox ORDER BY Id DESC");
?>
<table class="tbl">
  <tr><th>Id</th><th>Title</th><th>Complaints</th></tr>
  <?php while($r = mysqli_fetch_assoc($res)): ?>
  <tr><td><?= e($r['Id']) ?></td><td><?= e($r['Title']) ?></td><td><?= e($r['complaint']) ?></td></tr>
  <?php endwhile; ?>
</table>
<?php require 'footer.php'; ?>
