<?php
require 'db.php'; session_start();
$title = "Photo Gallery";
require 'header_user.php';
$res = mysqli_query($conn, "SELECT * FROM images ORDER BY id DESC");
?>
<h2 class="ptitle">Upload your Anonymous photos..!!</h2>
<?php if(!empty($_GET['error'])): ?><p class="err"><?= e($_GET['error']) ?></p><?php endif; ?>
<form action="picadd.php" method="POST" enctype="multipart/form-data" class="upl">
  <input type="file" name="my_image" required> <button type="submit" name="submit" class="btn">Upload</button>
</form>
<div class="gallery">
<?php while($r = mysqli_fetch_assoc($res)): ?>
  <div class="gal"><img src="uploads/<?= e($r['image_url']) ?>"></div>
<?php endwhile; ?>
</div>
<?php require 'footer.php'; ?>
