<?php
require 'db.php'; need_admin();
$st = mysqli_prepare($conn, "DELETE FROM registration WHERE Id=?");
mysqli_stmt_bind_param($st, "i", $_GET['id']);
mysqli_stmt_execute($st);
alert_go('Member deleted successfully...!', 'managemem.php');
