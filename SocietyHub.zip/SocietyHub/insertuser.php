<?php
require 'db.php'; need_admin();
if (isset($_POST['submit'])) {
  $st = mysqli_prepare($conn, "INSERT INTO registration (Username,Email,Flatno,MobileNo,`nno of family members`,Password) VALUES (?,?,?,?,?,?)");
  mysqli_stmt_bind_param($st, "ssiiis", $_POST['username'], $_POST['email'], $_POST['flatno'], $_POST['mobno'], $_POST['fammem'], $_POST['password']);
  if (mysqli_stmt_execute($st)) alert_go('Member added successfully...!', 'managemem.php');
  alert_go('Failed to add member.', 'managemem.php');
}
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Add Member</title><link rel="stylesheet" href="dashstyle.css"></head>
<body class="mint">
<form method="POST" class="mbox">
  <h2>Add Member</h2>
  <input name="username" placeholder="Username" required>
  <input type="email" name="email" placeholder="E-mail" required>
  <input name="flatno" placeholder="Flat-No." required>
  <input type="tel" name="mobno" placeholder="Mobile Number" required>
  <input name="fammem" placeholder="Number of Family members" required>
  <input type="password" name="password" placeholder="Password" required>
  <button name="submit" class="btn small">Save Data</button>
</form></body></html>
