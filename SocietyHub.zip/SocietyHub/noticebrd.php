<?php
require 'db.php'; session_start();
$title = "Notice Board";
require 'header_user.php';
$res = mysqli_query($conn, "SELECT * FROM notices ORDER BY Id DESC");
?>
<table class="tbl">
  <tr><th>No.</th><th>Notice Name</th><th>Notice Type</th><th>Date</th><th>Message</th></tr>
  <?php $i=1; while($r = mysqli_fetch_assoc($res)): ?>
  <tr><td><?= $i++ ?></td><td><?= e($r['Name']) ?></td><td><?= e($r['Type']) ?></td><td><?= e($r['Noticedate']) ?></td><td><?= e($r['Message']) ?></td></tr>
  <?php endwhile; ?>
</table>
<?php require 'footer.php'; ?>
