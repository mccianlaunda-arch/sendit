<?php
require 'db.php'; session_start();
$title = "Welcome";
require 'header_user.php';
$st = mysqli_prepare($conn, "SELECT Username,Flatno FROM registration WHERE Username=?");
mysqli_stmt_bind_param($st, "s", $_SESSION['username']);
mysqli_stmt_execute($st);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
?>
<div class="welcome-title">Welcome to Dashboard</div>
<div class="cards">
  <div class="card c1"><h3><?= e($row['Username']) ?></h3><small>Your Username</small><span class="ico">👤</span></div>
  <div class="card c2"><h3><?= e($row['Flatno']) ?></h3><small>Your Flat No.</small><span class="ico">🏠</span></div>
  <div class="card c3"><h3>Zakir Sayed</h3><small>Society Secretary</small><span class="ico">👤</span></div>
</div>
<?php require 'footer.php'; ?>
