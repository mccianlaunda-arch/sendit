<?php require 'db.php'; require 'upload_handler.php'; need_admin(); handle_upload($conn, 'photo.php');
