<?php
require 'db.php'; session_start();
if (!empty($_SESSION['admin']) && isset($_POST['send'])) {
  $st = mysqli_prepare($conn, "INSERT INTO notices (Name,Type,Noticedate,Message) VALUES (?,?,?,?)");
  mysqli_stmt_bind_param($st, "ssss", $_POST['name'], $_POST['type'], $_POST['date'], $_POST['message']);
  if (mysqli_stmt_execute($st)) alert_go('Notice added successfully...!', 'addnotice.php');
  alert_go('Failed to add notice.', 'addnotice.php');
}
$title = "Add notice";
require 'header_admin.php';
?>
<form method="POST" class="nform">
  <h2 class="ptitle">Create Notice</h2>
  <input class="field full" name="name" placeholder="Notice Name" required>
  <input class="field full" name="type" placeholder="Notice Type(Events,Subscribtion, Meeting, etc)" required>
  <input class="field full" type="date" name="date" required>
  <textarea class="field full" name="message" placeholder="Enter Your Message" maxlength="500" required></textarea>
  <button type="submit" name="send" class="btn full">Send</button>
</form>
<?php require 'footer.php'; ?>
